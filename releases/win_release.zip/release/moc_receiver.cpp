/****************************************************************************
** Meta object code from reading C++ file 'receiver.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Chess/receiver.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'receiver.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Receiver_t {
    QByteArrayData data[22];
    char stringdata0[206];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Receiver_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Receiver_t qt_meta_stringdata_Receiver = {
    {
QT_MOC_LITERAL(0, 0, 8), // "Receiver"
QT_MOC_LITERAL(1, 9, 13), // "receive_click"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 1), // "x"
QT_MOC_LITERAL(4, 26, 1), // "y"
QT_MOC_LITERAL(5, 28, 1), // "w"
QT_MOC_LITERAL(6, 30, 1), // "h"
QT_MOC_LITERAL(7, 32, 12), // "receive_mode"
QT_MOC_LITERAL(8, 45, 13), // "singlerplayer"
QT_MOC_LITERAL(9, 59, 18), // "receice_difficulty"
QT_MOC_LITERAL(10, 78, 10), // "difficulty"
QT_MOC_LITERAL(11, 89, 15), // "receive_newgame"
QT_MOC_LITERAL(12, 105, 7), // "newgame"
QT_MOC_LITERAL(13, 113, 11), // "receive_FEN"
QT_MOC_LITERAL(14, 125, 3), // "fen"
QT_MOC_LITERAL(15, 129, 4), // "file"
QT_MOC_LITERAL(16, 134, 11), // "QQuickItem*"
QT_MOC_LITERAL(17, 146, 9), // "selection"
QT_MOC_LITERAL(18, 156, 17), // "receive_promotion"
QT_MOC_LITERAL(19, 174, 9), // "promotion"
QT_MOC_LITERAL(20, 184, 12), // "receice_save"
QT_MOC_LITERAL(21, 197, 8) // "location"

    },
    "Receiver\0receive_click\0\0x\0y\0w\0h\0"
    "receive_mode\0singlerplayer\0"
    "receice_difficulty\0difficulty\0"
    "receive_newgame\0newgame\0receive_FEN\0"
    "fen\0file\0QQuickItem*\0selection\0"
    "receive_promotion\0promotion\0receice_save\0"
    "location"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Receiver[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    4,   49,    2, 0x0a /* Public */,
       7,    1,   58,    2, 0x0a /* Public */,
       9,    1,   61,    2, 0x0a /* Public */,
      11,    1,   64,    2, 0x0a /* Public */,
      13,    3,   67,    2, 0x0a /* Public */,
      18,    1,   74,    2, 0x0a /* Public */,
      20,    1,   77,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Double,    3,    4,    5,    6,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::Bool,   12,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool, 0x80000000 | 16,   14,   15,   17,
    QMetaType::Void, QMetaType::QString,   19,
    QMetaType::Bool, QMetaType::QString,   21,

       0        // eod
};

void Receiver::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Receiver *_t = static_cast<Receiver *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->receive_click((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4]))); break;
        case 1: _t->receive_mode((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->receice_difficulty((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->receive_newgame((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->receive_FEN((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< QQuickItem*(*)>(_a[3]))); break;
        case 5: _t->receive_promotion((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 6: { bool _r = _t->receice_save((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 2:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QQuickItem* >(); break;
            }
            break;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Receiver::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_Receiver.data,
    qt_meta_data_Receiver,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Receiver::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Receiver::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Receiver.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Receiver::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
